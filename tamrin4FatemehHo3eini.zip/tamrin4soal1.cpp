#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int n, m;
	cout << " Enter n , m: ";
	cin >> n >> m;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			if (j % 2 == i % 2)
				cout << "#";
			else
				cout << "*";
		}
		cout << endl;
	}
	
	getch();
    return 0;
}

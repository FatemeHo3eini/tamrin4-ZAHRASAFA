#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int num, fact = 1, flag = 1;
	cout << "Enter number: ";
	cin >> num;
	for (int i = 2; num >= fact; i++) {
		if (num == fact) {
			cout << "yes\n";
			flag = 0;
		}
		fact *= i;
	}
	if (flag)
		cout << "no\n";
	
	getch();
    return 0;
}

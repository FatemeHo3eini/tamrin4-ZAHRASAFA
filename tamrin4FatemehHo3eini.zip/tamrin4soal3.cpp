#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int num, num2, kmm, temp;
	cout << "Enter 2 number : ";
	cin >> num >> num2;
	if (num > num2)
		temp = num;
	else
		temp = num2;
	for (kmm = temp; kmm <= num*num2; kmm++)
		if (kmm%num == 0 && kmm%num2 == 0)
			break;

	cout << "K.M.M :  " << kmm << endl;
	
	getch();
    return 0;
}
